<?php

namespace ThunderByte;

use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    protected $fillable = [
        'numero', 'tipo'
    ];
}
