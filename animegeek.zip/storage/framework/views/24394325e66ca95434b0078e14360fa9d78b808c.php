<div class="message message-<?php echo e($color); ?>">
    <?php echo e($slot); ?>

</div>
